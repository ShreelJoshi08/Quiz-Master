document.addEventListener('DOMContentLoaded', function() {
    // Form Validation for Book Parking
    const bookParkingForm = document.getElementById('bookParkingForm');
    if (bookParkingForm) {
      bookParkingForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!this.checkValidity()) {
          e.stopPropagation();
          this.classList.add('was-validated');
          return;
        }
        
        if (!document.getElementById('slotId').value.match(/[A-Za-z0-9]{5}/)) {
          alert('Invalid Slot ID format (e.g., A1B2C)');
          return;
        }
        if (!document.getElementById('userId').value.match(/[0-9]{5}/)) {
          alert('Invalid User ID format (e.g., 12345)');
          return;
        }
        if (!document.getElementById('vehicleNumber').value.match(/[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{4}/)) {
          alert('Invalid Vehicle Number format (e.g., AB12CD3456)');
          return;
        }
        alert('Parking Slot Booked Successfully');
      });
    }
  
    // Form Validation for Release Parking
    const releaseParkingForm = document.getElementById('releaseParkingForm');
    if (releaseParkingForm) {
      releaseParkingForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!this.checkValidity()) {
          e.stopPropagation();
          this.classList.add('was-validated');
          return;
        }
        
        if (!document.getElementById('releaseSlotId').value.match(/[A-Za-z0-9]{5}/)) {
          alert('Invalid Slot ID format (e.g., A1B2C)');
          return;
        }
        if (!document.getElementById('releaseVehicle').value.match(/[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{4}/)) {
          alert('Invalid Vehicle Number format (e.g., AB12CD3456)');
          return;
        }
        if (!document.getElementById('parkingTime').value) {
          alert('Parking Time is required');
          return;
        }
        if (!document.getElementById('releaseCost').value) {
          alert('Total Cost is required');
          return;
        }
        alert('Parking Slot Released Successfully');
      });
    }
  
    // Pincode Search Function
    function searchByPincode() {
      const pincode = document.getElementById('pincodeSearch').value;
      if (!pincode.match(/[0-9]{6}/)) {
        alert('Please enter a valid 6-digit pincode');
        return;
      }
      alert(`Searching parking lots for pincode ${pincode}`);
      // Add your search logic here
    }
  });